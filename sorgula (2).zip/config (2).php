<?php
// Veritabanı bağlantısı için gerekli bilgiler
$servername = "sql311.infinityfree.com";
$username = "if0_37505179";
$password = "hFeblwc8KYWi";
$dbname = "if0_37505179_enesdb";

// Veritabanı bağlantısı
$conn = new mysqli($servername, $username, $password, $dbname);

// Bağlantı kontrolü
if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}

// Karakter setini ayarla
$conn->set_charset("utf8mb4");
mysqli_query($conn, "SET NAMES utf8mb4");
mysqli_query($conn, "SET CHARACTER SET utf8mb4");
mysqli_query($conn, "SET COLLATION_CONNECTION = 'utf8mb4_unicode_ci'");

// Oturum başlat
session_start();

// Hata raporlamasını aç
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>