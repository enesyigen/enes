<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kullanıcı Sorgulama Sistemi</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <style>
        :root {
            --primary-color: #4f46e5;
            --primary-hover: #4338ca;
            --primary-light: #c7d2fe;
            --bg-color: #f8fafc;
            --card-bg: #ffffff;
            --text-color: #0f172a;
            --text-light: #64748b;
            --text-xlight: #94a3b8;
            --border-color: #e2e8f0;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --info-color: #3b82f6;
            --card-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.05);
            --transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 16px;
            --font-sans: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
        }

        [data-theme="dark"] {
            --primary-color: #818cf8;
            --primary-hover: #6366f1;
            --primary-light: #312e81;
            --bg-color: #0f172a;
            --card-bg: #1e293b;
            --text-color: #f8fafc;
            --text-light: #94a3b8;
            --text-xlight: #64748b;
            --border-color: #334155;
            --card-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.2);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: var(--font-sans);
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            line-height: 1.6;
            transition: var(--transition);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header {
            padding: 60px 0 120px;
            text-align: center;
            position: relative;
            overflow: hidden;
            background-image: linear-gradient(135deg, var(--primary-color), var(--info-color));
        }

        .header-waves {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            overflow: hidden;
            line-height: 0;
            transform: rotate(180deg);
        }

        .header-waves svg {
            position: relative;
            display: block;
            width: calc(100% + 1.3px);
            height: 60px;
        }

        .header-waves .shape-fill {
            fill: var(--bg-color);
        }

        .header-content {
            position: relative;
            z-index: 1;
            padding: 0 20px;
        }

        .header h1 {
            font-size: 40px;
            font-weight: 800;
            margin-bottom: 8px;
            color: white;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .header p {
            font-size: 18px;
            max-width: 600px;
            margin: 0 auto;
            color: rgba(255,255,255,0.9);
        }

        .container {
            max-width: 800px;
            margin: -80px auto 60px;
            padding: 0 20px;
            flex: 1;
            position: relative;
            z-index: 10;
        }

        .card {
            background-color: var(--card-bg);
            border-radius: var(--radius-lg);
            padding: 32px;
            box-shadow: var(--card-shadow);
            margin-bottom: 32px;
            transition: var(--transition);
            border: 1px solid var(--border-color);
        }

        .form-group {
            margin-bottom: 24px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--text-color);
            font-size: 14px;
        }

        .input-container {
            position: relative;
        }

        .input-icon {
            position: absolute;
            top: 50%;
            left: 16px;
            transform: translateY(-50%);
            color: var(--text-light);
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 16px 16px 16px 48px;
            border: 1px solid var(--border-color);
            border-radius: var(--radius-md);
            font-size: 16px;
            background-color: var(--card-bg);
            color: var(--text-color);
            transition: var(--transition);
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 4px var(--primary-light);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 16px 24px;
            font-size: 16px;
            border-radius: var(--radius-md);
            cursor: pointer;
            transition: var(--transition);
            font-weight: 600;
            gap: 8px;
            width: 100%;
        }

        .btn:hover {
            background-color: var(--primary-hover);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(79, 70, 229, 0.4);
        }

        .footer {
            text-align: center;
            padding: 32px 20px;
            color: var(--text-light);
            font-size: 14px;
            margin-top: auto;
            background-color: var(--card-bg);
            border-top: 1px solid var(--border-color);
        }

        .theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 50%;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            z-index: 100;
            box-shadow: var(--card-shadow);
            transition: var(--transition);
        }

        .theme-toggle:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .theme-toggle i {
            font-size: 20px;
            color: var(--text-color);
        }

        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: var(--card-bg);
            box-shadow: var(--card-shadow);
            border-radius: var(--radius-md);
            padding: 16px;
            max-width: 300px;
            z-index: 1000;
            border-left: 4px solid var(--info-color);
            transform: translateX(120%);
            animation: slideIn 0.3s forwards, slideOut 0.3s 3s forwards;
        }

        @keyframes slideIn {
            to { transform: translateX(0); }
        }

        @keyframes slideOut {
            to { transform: translateX(120%); }
        }

        .notification.warning {
            border-left-color: var(--warning-color);
        }

        .notification.error {
            border-left-color: var(--danger-color);
        }

        .notification.success {
            border-left-color: var(--success-color);
        }

        .nav-links {
            display: flex;
            justify-content: center;
            margin-bottom: 32px;
            gap: 16px;
        }

        .nav-link {
            padding: 8px 16px;
            border-radius: var(--radius-md);
            text-decoration: none;
            color: var(--text-color);
            font-weight: 500;
            transition: var(--transition);
        }

        .nav-link:hover {
            background-color: var(--primary-light);
            color: var(--primary-color);
        }

        .nav-link.active {
            background-color: var(--primary-color);
            color: white;
        }

        .text-center {
            text-align: center;
        }

        .mt-4 {
            margin-top: 16px;
        }

        .link {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            transition: var(--transition);
        }

        .link:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .container {
                padding: 0 16px;
                margin-top: -60px;
            }
            
            .header {
                padding: 40px 0 100px;
            }
            
            .header h1 {
                font-size: 32px;
            }
            
            .header p {
                font-size: 16px;
            }
            
            .card {
                padding: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="theme-toggle" id="themeToggle">
        <i class="fas fa-moon"></i>
    </div>
    
    <div class="header">
        <div class="header-content">
            <h1 class="animate__animated animate__fadeInDown">Kullanıcı Sorgulama</h1>
            <p class="animate__animated animate__fadeInUp animate__delay-1s">Hesabınıza giriş yapın veya yeni bir hesap oluşturun</p>
        </div>
        <div class="header-waves">
            <svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
                <path d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z" opacity=".25" class="shape-fill"></path>
                <path d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z" opacity=".5" class="shape-fill"></path>
                <path d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z" class="shape-fill"></path>
            </svg>
        </div>
    </div>
    
    <div class="container animate__animated animate__fadeIn animate__delay-1s">
        <div class="nav-links">
            <a href="index.php" class="nav-link active">
                <i class="fas fa-search"></i> Sorgulama
            </a>
            <a href="kayit.php" class="nav-link">
                <i class="fas fa-user-plus"></i> Kayıt
            </a>
        </div>
        
        <div class="card">
            <form id="loginForm" method="post" action="giris_isle.php">
                <div class="form-group">
                    <label for="email">E-posta</label>
                    <div class="input-container">
                        <span class="input-icon">
                            <i class="fas fa-envelope"></i>
                        </span>
                        <input type="email" id="email" name="email" placeholder="E-posta adresiniz" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="sifre">Şifre</label>
                    <div class="input-container">
                        <span class="input-icon">
                            <i class="fas fa-lock"></i>
                        </span>
                        <input type="password" id="sifre" name="sifre" placeholder="Şifreniz" required>
                    </div>
                </div>
                
                <button type="submit" class="btn">
                    <i class="fas fa-sign-in-alt"></i>
                    <span>Giriş Yap</span>
                </button>
                
                <div class="text-center mt-4">
                    <p>Hesabınız yok mu? <a href="kayit.php" class="link">Hemen kaydolun</a></p>
                </div>
            </form>
        </div>
    </div>
    
    <div class="footer">
        <p>&copy; 2025 Kullanıcı Kayıt ve Sorgulama Sistemi | Tüm Hakları Saklıdır</p>
    </div>

    <div id="notification" style="display:none;" class="notification">
        <span id="notificationMessage"></span>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            // Tema değiştirme
            $("#themeToggle").click(function() {
                if (document.body.hasAttribute('data-theme')) {
                    document.body.removeAttribute('data-theme');
                    $("#themeToggle i").removeClass('fa-sun').addClass('fa-moon');
                    localStorage.setItem('theme', 'light');
                } else {
                    document.body.setAttribute('data-theme', 'dark');
                    $("#themeToggle i").removeClass('fa-moon').addClass('fa-sun');
                    localStorage.setItem('theme', 'dark');
                }
            });
            
            // Sayfa yüklendiğinde tema kontrolü
            if (localStorage.getItem('theme') === 'dark') {
                document.body.setAttribute('data-theme', 'dark');
                $("#themeToggle i").removeClass('fa-moon').addClass('fa-sun');
            }
            
            // Form gönderimi
            $("#loginForm").submit(function(e) {
                e.preventDefault();
                
                $.ajax({
                    url: "giris_isle.php",
                    type: "POST",
                    data: $(this).serialize(),
                    dataType: "json",
                    success: function(response) {
                        if (response.durum === "basarili") {
                            showNotification(response.mesaj, "success");
                            setTimeout(function() {
                                window.location.href = "dashboard.php";
                            }, 1500);
                        } else {
                            showNotification(response.mesaj, "error");
                        }
                    },
                    error: function() {
                        showNotification("Giriş işlemi sırasında bir hata oluştu.", "error");
                    }
                });
            });
            
            // Bildirim gösterme fonksiyonu
            function showNotification(message, type = "info") {
                const notification = $("#notification");
                notification.removeClass("info warning error success").addClass(type);
                $("#notificationMessage").text(message);
                notification.css("display", "block");
                
                setTimeout(function() {
                    notification.css("display", "none");
                }, 3500);
            }

            // URL'den mesaj parametresini al
            const urlParams = new URLSearchParams(window.location.search);
            const message = urlParams.get('mesaj');
            const status = urlParams.get('durum');
            
            if (message) {
                showNotification(decodeURIComponent(message), status || "info");
            }
        });
    </script>
</body>
</html>