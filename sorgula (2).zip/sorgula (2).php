<?php
// Veritabanı bağlantı dosyasını dahil et
require_once 'config.php';

// POST ile gönderilen ID değerini al
$kullaniciId = isset($_POST['id']) ? $_POST['id'] : 0;

// Cevap dizisi
$cevap = array();

// SQL sorgusu için hazırlık - tablonuzdaki tüm sütunları seçiyoruz (şifre hariç)
$sql = "SELECT id, ad_soyad, email, rol, kayit_tarihi FROM kullanicilar WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $kullaniciId);
$stmt->execute();
$result = $stmt->get_result();

// Sonucu kontrol et
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $cevap['durum'] = "basarili";
    $cevap['id'] = $row['id'];
    $cevap['ad_soyad'] = $row['ad_soyad'];
    $cevap['email'] = $row['email'];
    $cevap['rol'] = $row['rol'];
    $cevap['kayit_tarihi'] = $row['kayit_tarihi'];
} else {
    $cevap['durum'] = "basarisiz";
    $cevap['mesaj'] = "Kullanıcı bulunamadı";
}

// Sorgu bağlantısını kapat
$stmt->close();

// Veritabanı bağlantısını kapat
$conn->close();

// JSON formatında cevap döndür
header('Content-Type: application/json; charset=utf-8');
echo json_encode($cevap);
?>