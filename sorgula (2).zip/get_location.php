<?php
// Veritabanı bağlantı dosyasını dahil et
require_once 'config.php';

// POST ile gelen action parametresini al
$action = isset($_POST['action']) ? $_POST['action'] : '';

// Cevap dizisi
$response = array();

switch ($action) {
    case 'get_iller':
        // Tüm illeri getir
        $sql = "SELECT * FROM iller ORDER BY il_adi ASC";
        $result = $conn->query($sql);
        
        if ($result && $result->num_rows > 0) {
            $iller = array();
            while ($row = $result->fetch_assoc()) {
                $iller[] = $row;
            }
            $response['durum'] = "basarili";
            $response['iller'] = $iller;
        } else {
            $response['durum'] = "basarisiz";
            $response['mesaj'] = "İller bulunamadı";
        }
        break;
        
    case 'get_ilceler':
        // İl ID'sine göre ilçeleri getir
        $il_id = isset($_POST['il_id']) ? intval($_POST['il_id']) : 0;
        
        if ($il_id > 0) {
            $stmt = $conn->prepare("SELECT * FROM ilceler WHERE il_id = ? ORDER BY ilce_adi ASC");
            $stmt->bind_param("i", $il_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result && $result->num_rows > 0) {
                $ilceler = array();
                while ($row = $result->fetch_assoc()) {
                    $ilceler[] = $row;
                }
                $response['durum'] = "basarili";
                $response['ilceler'] = $ilceler;
            } else {
                $response['durum'] = "basarisiz";
                $response['mesaj'] = "Seçilen ile ait ilçe bulunamadı";
            }
            $stmt->close();
        } else {
            $response['durum'] = "basarisiz";
            $response['mesaj'] = "Geçersiz il ID";
        }
        break;
        
    case 'get_mahalleler':
        // İlçe ID'sine göre mahalleleri getir
        $ilce_id = isset($_POST['ilce_id']) ? intval($_POST['ilce_id']) : 0;
        
        if ($ilce_id > 0) {
            $stmt = $conn->prepare("SELECT * FROM mahalleler WHERE ilce_id = ? ORDER BY mahalle_adi ASC");
            $stmt->bind_param("i", $ilce_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result && $result->num_rows > 0) {
                $mahalleler = array();
                while ($row = $result->fetch_assoc()) {
                    $mahalleler[] = $row;
                }
                $response['durum'] = "basarili";
                $response['mahalleler'] = $mahalleler;
            } else {
                $response['durum'] = "basarisiz";
                $response['mesaj'] = "Seçilen ilçeye ait mahalle bulunamadı";
            }
            $stmt->close();
        } else {
            $response['durum'] = "basarisiz";
            $response['mesaj'] = "Geçersiz ilçe ID";
        }
        break;
        
    default:
        $response['durum'] = "basarisiz";
        $response['mesaj'] = "Geçersiz istek";
        break;
}

// Veritabanı bağlantısını kapat
$conn->close();

// JSON formatında cevap döndür
header('Content-Type: application/json; charset=utf-8');
echo json_encode($response);
?>