<?php
// Veritabanı bağlantı dosyasını dahil et
require_once 'config.php';

// Cevap dizisi
$response = array();

// Form verilerini al
$ad_soyad = isset($_POST['ad_soyad']) ? trim($_POST['ad_soyad']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$il_id = isset($_POST['il']) ? intval($_POST['il']) : 0;
$ilce_id = isset($_POST['ilce']) ? intval($_POST['ilce']) : 0;
$mahalle_id = isset($_POST['mahalle']) ? intval($_POST['mahalle']) : 0;
$sifre = isset($_POST['sifre']) ? $_POST['sifre'] : '';
$sifre_tekrar = isset($_POST['sifre_tekrar']) ? $_POST['sifre_tekrar'] : '';

// Temel doğrulama kontrolleri
if (empty($ad_soyad) || empty($email) || empty($sifre) || empty($sifre_tekrar) || $il_id <= 0 || $ilce_id <= 0 || $mahalle_id <= 0) {
    $response['durum'] = "basarisiz";
    $response['mesaj'] = "Lütfen tüm alanları doldurunuz.";
    echo json_encode($response);
    exit;
}

// Şifre eşleşme kontrolü
if ($sifre !== $sifre_tekrar) {
    $response['durum'] = "basarisiz";
    $response['mesaj'] = "Şifreler eşleşmiyor.";
    echo json_encode($response);
    exit;
}

// Email formatı kontrolü
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $response['durum'] = "basarisiz";
    $response['mesaj'] = "Geçerli bir e-posta adresi giriniz.";
    echo json_encode($response);
    exit;
}

// E-posta adresi kullanımda mı kontrolü
$stmt = $conn->prepare("SELECT id FROM kullanicilar WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $response['durum'] = "basarisiz";
    $response['mesaj'] = "Bu e-posta adresi zaten kullanımda.";
    echo json_encode($response);
    $stmt->close();
    exit;
}
$stmt->close();

// Şifreyi hashleme
$hashed_password = password_hash($sifre, PASSWORD_DEFAULT);

// Kayıt tarihini al
$kayit_tarihi = date("Y-m-d H:i:s");

// Kullanıcıyı veritabanına ekle
$stmt = $conn->prepare("INSERT INTO kullanicilar (ad_soyad, email, sifre, il_id, ilce_id, mahalle_id, kayit_tarihi) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssiiis", $ad_soyad, $email, $hashed_password, $il_id, $ilce_id, $mahalle_id, $kayit_tarihi);

if ($stmt->execute()) {
    $response['durum'] = "basarili";
    $response['mesaj'] = "Kayıt işlemi başarıyla tamamlandı. Giriş sayfasına yönlendiriliyorsunuz...";
} else {
    $response['durum'] = "basarisiz";
    $response['mesaj'] = "Kayıt işlemi sırasında bir hata oluştu: " . $stmt->error;
}

$stmt->close();
$conn->close();

// JSON formatında cevap döndür
header('Content-Type: application/json; charset=utf-8');
echo json_encode($response);
?>