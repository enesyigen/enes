<?php
// Oturum başlat
session_start();

// Veritabanı bağlantı dosyasını dahil et
require_once 'config.php';

// Cevap dizisi
$response = array();

// Form verilerini al
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$sifre = isset($_POST['sifre']) ? $_POST['sifre'] : '';

// Temel doğrulama kontrolleri
if (empty($email) || empty($sifre)) {
    $response['durum'] = "basarisiz";
    $response['mesaj'] = "Lütfen tüm alanları doldurunuz.";
    echo json_encode($response);
    exit;
}

// Email formatı kontrolü
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $response['durum'] = "basarisiz";
    $response['mesaj'] = "Geçerli bir e-posta adresi giriniz.";
    echo json_encode($response);
    exit;
}

// Kullanıcıyı veritabanında kontrol et
$stmt = $conn->prepare("SELECT id, ad_soyad, email, sifre FROM kullanicilar WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
    
    // Şifreyi doğrula
    if (password_verify($sifre, $user['sifre'])) {
        // Oturum değişkenlerini ayarla
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['ad_soyad'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['logged_in'] = true;
        
        // Başarılı giriş yanıtı
        $response['durum'] = "basarili";
        $response['mesaj'] = "Giriş başarılı, yönlendiriliyorsunuz.";
        $response['yonlendir'] = "panel.php";
    } else {
        // Şifre yanlış
        $response['durum'] = "basarisiz";
        $response['mesaj'] = "E-posta veya şifre hatalı.";
    }
} else {
    // Kullanıcı bulunamadı veya aktif değil
    $response['durum'] = "basarisiz";
    $response['mesaj'] = "E-posta veya şifre hatalı.";
}

// Veritabanı bağlantısını kapat
$stmt->close();
$conn->close();

// JSON yanıtını döndür
header('Content-Type: application/json');
echo json_encode($response);
exit;
?>